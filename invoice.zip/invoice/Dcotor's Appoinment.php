<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="manifest" href="site.webmanifest">
        <link rel="apple-touch-icon" href="icon.png">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css"/>
		
		<link rel="stylesheet" href="main.css"/>


		
  
    

<style type="text/css">
	
</style>
    </head>
<body>
        <!-- header section Start -->
<div class="header_section">
	
	<nav class="navbar navbar-default">
	  <div class="container">
	    
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      <ul class="nav navbar-nav">
	      	<li><a href="index.html"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
	        <li><a href="index.html"><i class="fa fa-user" aria-hidden="true">
			</i> Speclized Dcotor List</a></li>
	        <li><a href="#"><i class="fa fa-question" aria-hidden="true"></i> Dcotor's Appoinment</a></li>
			<li><a href=""><i class="fa fa-question" aria-hidden="true"></i> Contact</a></li>
            </ul>

            <ul class="nav navbar-nav navbar-right">
            <li><a href="login/index.html"><i class="fa fa-user" aria-hidden="true"></i>Login</a></li>
	      </ul>

	      
	    </div>
	  </div>
	</nav>
	
</div>

</body>
</html>