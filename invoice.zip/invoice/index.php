<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="manifest" href="site.webmanifest">
        <link rel="apple-touch-icon" href="icon.png">
        <link rel="stylesheet" href="bootstrap/css/bootstrap.css"/>
		
		<link rel="stylesheet" href="main.css"/>


		
  
    

<style type="text/css">
	
</style>
    </head>
<body>
        <!-- header section Start -->
<div class="header_section">
	
	<nav class="navbar navbar-default">
	  <div class="container">
	    
	    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      <ul class="nav navbar-nav">
	      	<li><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
	        <li><a href="index.php"><i class="fa fa-user" aria-hidden="true">
			</i> Speclized Dcotor List</a></li>
	       <!-- <li><a href="get_doctors_appoinment.html"><i class="fa fa-question" aria-hidden="true"></i>Get Dcotor's Appoinment</a></li> -->
			<li><a href="get_doctors_appoinment.html" class="btn btn-info btn-xs">Get Dcotor's Appoinment</a></li>
			<li><a href=""><i class="fa fa-question" aria-hidden="true"></i> Contact</a></li>
            </ul>

            <ul class="nav navbar-nav navbar-right">
            <li><a href="login.php"><i class="fa fa-user" aria-hidden="true"></i>Login</a></li>
	      </ul>

	      
	    </div>
	  </div>
	</nav>
	
</div>

<!-- Team section start -->
<div class="about_section" f >
	<div class="container">
		<div class="row">
			
			<div class="col-sm-12">
				<div class="about_content">
				<!--	<img src="img/team.jpg" alt="About Company" class="img-responsive center-block">-->
					<h2>Doctors</h2>
					<div class="team_mumbers">
						
						
					<h3><b>Dr. Mirza Mohammad Ziaul Islam</b></h3>
						<p><b>Qualifications:MBBS, MD (Pediatrics)</br>
								Specialty: Pediatrics</br>
								Language Spoken: English, Bangla</br>
								Designation: Assistant Professor</b></p>
								<p>Institute: Dhaka Shishu Hospital, Shyamoli, Dhaka</br>
								Department Name:Pediatrics</p>	
												
					</div>
					
					
					
				</div>
				
			</div>
		</div>
	</div>
</div>

<div class="about_section" f >
	<div class="container">
		<div class="row">
			
			<div class="col-sm-12">
				<div class="about_content">
				
					<div class="team_mumbers">
						
						<h3><b>Professor Dr. Mirza Mohammad Hiron</b></h3>
						<p><b>Pulmonology & Medicine</br>
							Ibn Sina Diagnostic & Imaging Center, Dhanmondi</b></p>
						<p>Hot Line: 10615, +88 09610010615</p>
						
						
						
						
					</div>
					
					
					
				</div>
				
			</div>
		</div>
	</div>
</div>

<div class="about_section" f >
	<div class="container">
		<div class="row">
			
			<div class="col-sm-12">
				<div class="about_content">
									
					<div class="team_mumbers">
						
						<h3><b>Professor Dr. Mirza Mohammad Hiron</b></h3>
						<p><b>Pulmonology & Medicine</br>
							Ibn Sina Diagnostic & Imaging Center, Dhanmondi</b></p>
						<p>Hot Line: 10615, +88 09610010615</p>
						
						
					</div>
					
					
					
				</div>
				
			</div>
		</div>
	</div>
</div>

<div class="about_section" f >
	<div class="container">
		<div class="row">
			
			<div class="col-sm-12">
				<div class="about_content">
							
					<div class="team_mumbers">
						
						<h3><b>Professor Dr. Mirza Mohammad Hiron</b></h3>
						<p><b>Pulmonology & Medicine</br>
							Ibn Sina Diagnostic & Imaging Center, Dhanmondi</b></p>
						<p>Hot Line: 10615, +88 09610010615</p>
						
						
					</div>
					
					
					
				</div>
				
			</div>
		</div>
	</div>
</div>

<div class="about_section" f >
	<div class="container">
		<div class="row">
			
			<div class="col-sm-12">
				<div class="about_content">
				
					
					<div class="team_mumbers">
						
						<h3><b>Professor Dr. Mirza Mohammad Hiron</b></h3>
						<p><b>Pulmonology & Medicine</br>
							Ibn Sina Diagnostic & Imaging Center, Dhanmondi</b></p>
						<p>Hot Line: 10615, +88 09610010615</p>
					</div>
					
					
					
				</div>
				
			</div>
		</div>
	</div>
</div>
<!-- Team section End -->


</body>
</html>